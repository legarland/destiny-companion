var myApp = angular.module('myApp', ['angular.filter',
														'ngCookies',
														'displayFilters',
														'ui.bootstrap',
														'toastr',
														'ui-rangeSlider']);